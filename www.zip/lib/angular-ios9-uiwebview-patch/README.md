# angular-ios9-uiwebview-patch
Bower and NPM support for [IgorMinar's iOS9 Patch for Angular 1.2.0-1.4.5](https://gist.github.com/IgorMinar/863acd413e3925bf282c)
